package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.dao.PilotDaoImpl;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("PilotService")
public class PilotServiceImpl implements IPilotService{

	@Autowired
	IPilotDao pilotDao=new PilotDaoImpl();
	
	@Override
	public void savePilot(Pilot pilot) {
		pilotDao.savePilot(pilot);
		
	}

	@Override
	public List<Pilot> getAllPilots() {
		
		return pilotDao.getAllPilots();
	}

	@Override
	public void deletePilot(Integer pilotId) {
		pilotDao.deletePilot(pilotId);
		
	}

}
