package org.cap.util;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Pilot;

public class PilotUtil {
	
	public static List<String> getAllCities(){
		List<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Pune");
		cities.add("Hyderabad");cities.add("Bangalore");
		cities.add("Mubai");
		cities.add("Gurgaon");
		return cities;
		
	}
	public static List<String> getAllQualifications(){
		List<String> qualifications=new ArrayList<>();
		qualifications.add("B.Tech");
		qualifications.add("M.Teach");
		qualifications.add("MBA");
		qualifications.add("B.Sc");
		qualifications.add("M.Sc");
		return qualifications;
		
	}
	
	
}
