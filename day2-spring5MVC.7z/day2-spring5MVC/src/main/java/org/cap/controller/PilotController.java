package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Pilot;
import org.cap.service.IPilotService;
import org.cap.util.PilotUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@EnableTransactionManagement
public class PilotController {

	@Autowired
	private IPilotService pilotService;
	
	
	@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	public String savePilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(result.hasErrors())
			return "pilotPage";
		else
			pilotService.savePilot(pilot);
		//System.out.println(pilot);
			return "redirect:/pilotPage";
	}
	
	@RequestMapping("/pilotPage")
	public String pilotPage(ModelMap map) {
		map.addAttribute("pilot", new Pilot());
		map.addAttribute("cities", PilotUtil.getAllCities());
		map.addAttribute("qualifications", PilotUtil.getAllQualifications());
		map.addAttribute("pilots",pilotService.getAllPilots());
		return "pilotPage";
	}
	
	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
		
		pilotService.deletePilot(pilotId);
		return "redirect:/pilotPage";
	}
	
	@GetMapping("/update/{pilotId}")
	public String updatePilot(@PathVariable("pilotId") Integer pilotId) {
		
		//pilotService.deletePilot(pilotId);
		return "update";
	}
	
	
}
